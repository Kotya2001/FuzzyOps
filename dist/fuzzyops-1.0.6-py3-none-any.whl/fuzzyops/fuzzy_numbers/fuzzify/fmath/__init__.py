from .logic import fuzzy_or_mm, fuzzy_and_mm, fuzzy_and_prob,\
    fuzzy_or_prob
from .operations import *
