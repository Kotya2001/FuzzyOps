'''
from fuzzyops.graphs.fuzzgraph.numbers.tri_num import GraphTriangleFuzzyNumber

a = GraphTriangleFuzzyNumber([1, 1, 1])

'''

from .tri_num import GraphTriangleFuzzyNumber
