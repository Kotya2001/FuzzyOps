from .network import FuzzyNNetwork
